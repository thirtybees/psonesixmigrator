<?php
namespace PsOneSixMigrator\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException {}

<?php
namespace PsOneSixMigrator\GuzzleHttp\Exception;

interface GuzzleException {}

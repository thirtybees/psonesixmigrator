<?php
namespace PsOneSixMigrator\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException {}
